# Perch

An AI chat, one click away in your system tray.
Perch puts any web-based AI assistant in a small window on the right side of your screen. Click the
tray icon to open it, click outside (or press Esc) to hide it. You choose the service: Gemini, ChatGPT,
Claude, or any web address.

Built with Qt 6 and QtWebEngine (Chromium) for KDE Plasma.

## Dependencies
- Fedora:   `sudo dnf install qt6-qtbase-devel qt6-qtwebengine-devel qt6-linguist meson gcc-c++ cmake`
- Arch:     `sudo pacman -S qt6-base qt6-webengine qt6-tools meson`
- openSUSE: `sudo zypper in qt6-base-devel qt6-webengine-devel qt6-linguist-devel meson gcc-c++`
- Debian/Ubuntu: `sudo apt install qt6-base-dev qt6-webengine-dev qt6-l10n-tools meson g++`

The Linguist tools (`lrelease`) are needed to build the translations (they get embedded in the executable).
Without them Perch still builds, but in English only: check the `meson setup` output for
"building WITHOUT translations".

## Build and install
    find . -exec touch {} +
    meson setup build --prefix=$HOME/.local
    meson compile -C build
    meson install -C build
    perch &

Start with your session: `cp ~/.local/share/applications/io.FlaipyTheHost.Perch.desktop ~/.config/autostart/`

## Usage
- Left-click the tray icon: show/hide. Right-click: Settings / Quit.
- Running `perch` again toggles the window (handy for a keyboard shortcut).
- On first run, Settings opens so you can pick a service or type any URL.
- Config: `~/.config/perch/config.ini` (`margin` = distance from the screen edge,
  `user_agent` = User-Agent sent to websites).
- Sessions/logins are stored in `~/.local/share/perch/`.

## Languages
English, Portuguese (pt) and Spanish (es). Perch follows the system language automatically.
If it doesn't, run `PERCH_I18N_DEBUG=1 perch` to see the detected locale and whether the translation loaded.
To add a language: copy `translations/perch_es.ts` to `translations/perch_<lang>.ts`, translate it
(Qt Linguist or any editor), and list it in `translations/meson.build`.

## Notes
- Perch runs through XWayland (xcb) so it can position its window. To force native Wayland:
  `QT_QPA_PLATFORM=wayland perch` (the compositor then decides the position).
- Some sign-in pages (e.g. Google) refuse embedded browsers. Perch identifies as Firefox and disables
  Chromium Client Hints to avoid that; if a site blocks you, edit `user_agent` in the config.
